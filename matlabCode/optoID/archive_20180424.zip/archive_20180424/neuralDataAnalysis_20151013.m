%% Light identification
sessionToImport = {'mBB004d20150915_lightStim\b_10Hz,20ms'};
latencyToResponse = optogeneticIdentification_rasters(sessionToImport);

%% Uncertainty task analysis
% sessionToImport = {'mBB004d20150914'};
% blocks = [21, 60, 93, 115, 139, 178, 200, 222, 246, 269, 299, 321, 354, 393, 423];
% rewards = [80, 50, 80, 50, 30, 80, 50, 80, 50, 30, 50, 80, 30, 50, 80];

% sessionToImport = {'mBB004d20150915'};
% blocks = [22, 56, 85, 114, 145, 176, 199, 222, 249, 278, 313, 339, 366, 402, 427];
% rewards = [80, 30, 80, 30, 50, 80, 30, 50, 80, 30, 80, 30, 50, 30, 50];
% % 
sessionToImport = {'mBB004d20150916'};
blocks = [30, 52, 84, 121, 141, 181, 206, 231, 254, 282, 312, 345, 371, 411, 441];
rewards = [80, 30, 80, 50, 30, 50, 80, 50, 80, 30, 80, 50, 80, 50, 30];
% % 
% sessionToImport = {'mBB004d20150917'};
% blocks = [36, 72, 98, 131, 159, 187, 225, 263, 290, 330, 368, 392, 417, 453, 487];
% rewards = [80, 30, 80, 30, 80, 30, 80, 30, 80, 30, 80, 30, 80, 30, 80];

% [rewardRate, regCoeff, tC, lickRate, smoothLicks, blocks_csmin] = analyzeTrialData_model_uU(sessionToImport,blocks,rewards,0);
[licksP spikesP licksM spikesM] = analyzeTrialData_rasters_uU(sessionToImport);
% analyzeTrialData_fullSession_uU(sessionToImport, [200 1000], blocks, rewards, tC);

%%
LineFormat.LineWidth = 1;
subplot(3,1,1); plotSpikeRaster(logical(spikesP{3}([24:29 72:77 180:185 217:223],:)),'PlotType','vertline','RelSpikeStartTime',-1.5,'LineFormat',LineFormat);
ylim([0 33]); title('Last few trials of 80% block')
subplot(3,1,2); plotSpikeRaster(logical(spikesP{3}([42:47 124:129 244:249],:)),'PlotType','vertline','RelSpikeStartTime',-1.5,'LineFormat',LineFormat);
ylim([0 33]); title('Last few trials of 30% block')
subplot(3,1,3); plotSpikeRaster(logical(spikesM{3}),'PlotType','vertline','RelSpikeStartTime',-1.5,'LineFormat',LineFormat);
ylim([0 33]); title('All CS minus')

for i = 1:3
    subplot(3,1,i);
    plotShaded([0 1000], [0 0; 33 33], [119 119 119]./255)
    plotShaded([2000 2063], [0 0; 33 33], [30 114 255]./255)
    plotShaded([2063+3000 2063+3000+150], [0 0; 33 33], [119 119 119]./255)
end

%%
LineFormat.LineWidth = 1;
subplot(3,1,1); plotSpikeRaster(logical(spikesP{3}(logical([sessionData.CSplus.Rewarded]),:)),'PlotType','vertline','RelSpikeStartTime',-1.5,'LineFormat',LineFormat);
ylim([0 156]); title('Rewarded Trials')
subplot(3,1,2); plotSpikeRaster(logical(spikesP{3}(~logical([sessionData.CSplus.Rewarded]), :)),'PlotType','vertline','RelSpikeStartTime',-1.5,'LineFormat',LineFormat);
ylim([0 156]); title('Non-rewarded trials')

for i = 1:2
    subplot(3,1,i);
    plotShaded([0 1000], [0 0; 500 500], [119 119 119]./255)
    plotShaded([2000 2063], [0 0; 500 500], [30 114 255]./255)
    plotShaded([2063+3000 2063+3000+150], [0 0; 500 500], [119 119 119]./255)
end
%% Pupil-LC correlation
sessionToImport = {'mBB004d20150915'};
correlatePupilNeuralData(sessionToImport)
%% Interactive plot 7/3
load('D:\Locus Coeruleus Project\Data\BB004\mBB004d20150915\Pupil\mBB004d201509015a.mat')
load('D:\Locus Coeruleus Project\Data\BB004\mBB004d20150915\Sorted\a_pupil_timingCorrected.mat', 'pupilDiameter_c','threshValuesUsed')
load('D:\Locus Coeruleus Project\Data\BB004\mBB004d20150915\Sorted\sessionPupilData.mat')

pupilDiameter_smooth = pupilDiameter_c;    
pupilDiameter_smooth(pupilDiameter_smooth > 1.9) = NaN; % Impose a maximum pupil size of 1.9mm
   
pupilDiameter_smooth(isnan(pupilDiameter_smooth)) = interp1(find(~isnan(pupilDiameter_smooth)), pupilDiameter_smooth(~isnan(pupilDiameter_smooth)), find(isnan(pupilDiameter_smooth)),'cubic');
DataMatrix(1:length(pupilDiameter_smooth),1) = 1:length(pupilDiameter_smooth);
DataMatrix(1:length(pupilDiameter_smooth),2) = pupilDiameter_smooth';
pupilDiameter_smooth = isignal(DataMatrix,2500,4999,4,9,0,0,0,10,1000,0,0,0);
pupilDiameter_smooth = pupilDiameter_smooth';

i = 1;
plotPupilDataArrows(pupilMov, pupilDiameter_smooth, threshValuesUsed, i)