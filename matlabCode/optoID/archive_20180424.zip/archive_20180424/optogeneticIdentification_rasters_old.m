function [latencyToResponse] = optogeneticIdentification_rasters_old(sessionsToImport)

animalName = strtok(sessionsToImport{:}, 'd'); animalName = animalName(2:end);
sessionName = sessionsToImport{:};
if exist(strcat('D:\Locus Coeruleus Project\Data\', animalName, '\', sessionName, '\Sorted\laserStruct.mat'),'file')
    load(strcat('D:\Locus Coeruleus Project\Data\', animalName, '\', sessionName, '\Sorted\laserStruct.mat'))
else
    [~, ~, laserStruct] = generateTrialStruct_uU(sessionsToImport);
    save(strcat('D:\Locus Coeruleus Project\Data\', animalName, '\', sessionName, '\Sorted\laserStruct.mat'), 'laserStruct')
end

% find cluster data
spikeFields = fields(laserStruct);
clust = find(~cellfun(@isempty,strfind(spikeFields,'SS')) & ~cellfun(@isempty,strfind(spikeFields,'TT')));

sCon = 0.000000030518510385491027*1e6; %converts spike amplitude to uV
tB = 500; % ms before first pulse
tF = 500; % ms after last pulse
numPulses = 10; %number of pulses in each train
numTrains = length(laserStruct.laserOn)/numPulses;
rasterLength = length(-1*tB:laserStruct.laserOff(numPulses)-laserStruct.laserOn(1)+tF);

latencyToResponse = [];
numResponses = [];
spikeCSC_light = [];
spikeCSC_spont = [];

test_lightSpikes = [];
test_spontSpikes = [];

for i = clust'
    CSCchann = spikeFields{i}(end-4:end);
    trainInd = 1:numPulses:length(laserStruct.laserOn);
    for j = trainInd
        lL = laserStruct.laserOn(j) - tB;
        uL = laserStruct.laserOff(j+numPulses-1) + tF;
        test_lightSpikes = [test_lightSpikes laserStruct.(spikeFields{i})(laserStruct.(spikeFields{i}) >= lL & laserStruct.(spikeFields{i}) < uL) - laserStruct.laserOn(j)];
        spikeInds = laserStruct.(spikeFields{i})(laserStruct.(spikeFields{i}) >= lL & laserStruct.(spikeFields{i}) < uL) - laserStruct.laserOn(j) + tB;
        spikeRast(ceil(j/numPulses),1) = {spikeInds};
        
        laserOnInds = laserStruct.laserOn(laserStruct.laserOn >= lL & laserStruct.laserOn < uL) - laserStruct.laserOn(j) + tB;
        laserOffInds = laserStruct.laserOff(laserStruct.laserOff >= lL & laserStruct.laserOff < uL) - laserStruct.laserOn(j) + tB;
        laserRast(ceil(j/numPulses),1) = {sort([laserOnInds laserOffInds])};
%         laserRast(ceil(j/numPulses),1) = {laserOnInds};
        
        for k = 1:numPulses
            firstSpike = laserStruct.(spikeFields{i})(find(laserStruct.(spikeFields{i}) > laserStruct.laserOn(j+k-1),1));
            tempLat = firstSpike - laserStruct.laserOn(j+k-1);
            if tempLat < 30 %30ms limit to evoke a spike
                latencyToResponse(ceil(j/numPulses),k) = tempLat;
                numResponses(ceil(j/numPulses),k) = 1;
                [spikeCSC_light{ceil(j/numPulses),k}] = Nlx2MatCSC(strcat('D:\Locus Coeruleus Project\Data\', animalName, '\', sessionName, '\Unsorted\', CSCchann,'.ncs'),[0 0 0 0 1],0,5,firstSpike*1000);               
            else
                latencyToResponse(ceil(j/numPulses),k) = NaN;
                numResponses(ceil(j/numPulses),k) = 0;
            end
        end
        if j == 1
            sponSpike = laserStruct.(spikeFields{i})(laserStruct.(spikeFields{i})  < lL);
        elseif j == trainInd(end)
            sponSpike = laserStruct.(spikeFields{i})(laserStruct.(spikeFields{i})  >= uL);
            
        else
            nuL = laserStruct.laserOff(j+numPulses) - tB;
            sponSpike = laserStruct.(spikeFields{i})(laserStruct.(spikeFields{i}) >= uL & laserStruct.(spikeFields{i}) < nuL);
        end
        test_spontSpikes = [test_spontSpikes sponSpike];
        for m = 1:length(sponSpike)
            spikeCSC_spont = [spikeCSC_spont {Nlx2MatCSC(strcat('D:\Locus Coeruleus Project\Data\', animalName, '\', sessionName, '\Unsorted\', CSCchann,'.ncs'),[0 0 0 0 1],0,5,sponSpike(m)*1000)}]; 
        end
    end
    
    %sort spike data by threshold
    thresh = -5000;
    spikesThresholded = [];
    spontSpikesThresholded = [];
    padding = 75;

    tempMax = cellfun(@max,spikeCSC_spont);
    tempMin = cellfun(@min,spikeCSC_spont);
    if median(tempMax) >= abs(median(tempMin))
        for l = 1:length(spikeCSC_light(1:end))
    %         tempSpike = find(spikeCSC_light{l} < thresh,1);
            [~, tempSpike] = max(spikeCSC_light{l});
            if ~isempty(tempSpike)
                if tempSpike > padding && tempSpike < 512-padding
                    spikesThresholded = [spikesThresholded {spikeCSC_light{l}(tempSpike-padding:tempSpike+padding)}];
                elseif tempSpike <= padding
                    spikesThresholded = [spikesThresholded {[NaN(padding-tempSpike+1,1); spikeCSC_light{l}(1:tempSpike+padding)]}];
                elseif tempSpike >= 512-padding
                    spikesThresholded = [spikesThresholded {[spikeCSC_light{l}(tempSpike-padding:end); NaN(abs(512-tempSpike-padding),1)]}];
                end
            end
        end
        for l = 1:length(spikeCSC_spont)
    %         tempSpike = find(spikeCSC_spont{l} < thresh,1);
            [~, tempSpike] = max(spikeCSC_spont{l});
            if ~isempty(tempSpike)
                if tempSpike > padding && tempSpike < 512-padding
                    spontSpikesThresholded = [spontSpikesThresholded {spikeCSC_spont{l}(tempSpike-padding:tempSpike+padding)}];
                elseif tempSpike <= padding
                    spontSpikesThresholded = [spontSpikesThresholded {[NaN(padding-tempSpike+1,1); spikeCSC_spont{l}(1:tempSpike+padding)]}];
                elseif tempSpike >= 512-padding
                    spontSpikesThresholded = [spontSpikesThresholded {[spikeCSC_spont{l}(tempSpike-padding:end); NaN(abs(512-tempSpike-padding),1)]}];
                end
            end
        end
    elseif abs(median(tempMin)) > median(tempMax)
        for l = 1:length(spikeCSC_light(1:end))
    %         tempSpike = find(spikeCSC_light{l} < thresh,1);
            [~, tempSpike] = min(spikeCSC_light{l});
            if ~isempty(tempSpike)
                if tempSpike > padding && tempSpike < 512-padding
                    spikesThresholded = [spikesThresholded {spikeCSC_light{l}(tempSpike-padding:tempSpike+padding)}];
                elseif tempSpike <= padding
                    spikesThresholded = [spikesThresholded {[NaN(padding-tempSpike+1,1); spikeCSC_light{l}(1:tempSpike+padding)]}];
                elseif tempSpike >= 512-padding
                    spikesThresholded = [spikesThresholded {[spikeCSC_light{l}(tempSpike-padding:end); NaN(abs(512-tempSpike-padding),1)]}];
                end
            end
        end
        for l = 1:length(spikeCSC_spont)
    %         tempSpike = find(spikeCSC_spont{l} < thresh,1);
            [~, tempSpike] = min(spikeCSC_spont{l});
            if ~isempty(tempSpike)
                if tempSpike > padding && tempSpike < 512-padding
                    spontSpikesThresholded = [spontSpikesThresholded {spikeCSC_spont{l}(tempSpike-padding:tempSpike+padding)}];
                elseif tempSpike <= padding
                    spontSpikesThresholded = [spontSpikesThresholded {[NaN(padding-tempSpike+1,1); spikeCSC_spont{l}(1:tempSpike+padding)]}];
                elseif tempSpike >= 512-padding
                    spontSpikesThresholded = [spontSpikesThresholded {[spikeCSC_spont{l}(tempSpike-padding:end); NaN(abs(512-tempSpike-padding),1)]}];
                end
            end
        end
    end
    
    figure; subplot(4,3,[1:6]); hold on; title(strcat(spikeFields{i},' ;  ', sessionName),'Interpreter','none')
    xlabel('Time (ms)'); ylabel('Trials')
    LineFormat.Color = 'k'; LineFormat.LineWidth = 1;
    plotSpikeRaster(spikeRast,'PlotType','vertline','RelSpikeStartTime',-tB,'XLimForCell',[-1*tB rasterLength-tB],'LineFormat',LineFormat);
    hold on;
    for l = 1:2:length(laserRast{1})
        plotShaded([laserRast{1}(l)-tB laserRast{1}(l+1)-tB],[0 0; 1+numTrains 1+numTrains],'b')
    end
%     plot([laserRast{1}; laserRast{1}]-tB, [zeros(1,length(laserRast{1})); ones(1,length(laserRast{1}))*0.5],'b','LineWidth',1)
%     LineFormat.Color = 'b'; LineFormat.LineWidth = 1;
%     plotSpikeRaster(laserRast,'PlotType','vertline','RelSpikeStartTime',-tB,'XLimForCell',[-1*tB rasterLength-tB],'LineFormat',LineFormat);
    
    
    subplot(4,3,[7]); hold on;
    xlabel('Pulse'); ylabel('Latency (ms)'); ylim([8 25]); xlim([0 size(latencyToResponse,2)+1])
    plot(nanmean(latencyToResponse))
    
    subplot(4,3,10); hold on;
    xlabel('Pulse'); ylabel('Response Fraction'); ylim([-0.1 1.1]); xlim([0 size(numResponses,2)+1])
    plot(sum(numResponses)/size(numResponses,1))
    
    subplot(4,3,8);
    plot([1:length(spikesThresholded{1,1})]/32-32*padding/1000, nanmean(sCon*[spikesThresholded{:,:}]'),'b')
    subplot(4,3,11); hold on
    xlabel('Time (ms)')
    plot([1:length(spontSpikesThresholded{1,1})]/32-32*padding/1000, nanmean(sCon*[spontSpikesThresholded{:,:}]'),'k')
    
    subplot(4,3,[9 12]); hold on
    xlabel('Time (ms)');
    errorfill([1:length(spikesThresholded{1,1})]/32-32*padding/1000, nanmean(sCon*[spikesThresholded{:,:}]'), nanstd(sCon*[spikesThresholded{:,:}]'),'b')
    errorfill([1:length(spontSpikesThresholded{1,1})]/32-32*padding/1000, nanmean(sCon*[spontSpikesThresholded{:,:}]'), nanstd(sCon*[spontSpikesThresholded{:,:}]'),'k')
end